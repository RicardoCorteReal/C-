﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrawShapes
{
    public partial class Shapes : Form
    {

        internal System.Windows.Forms.ContextMenu mnuLabel;
        private System.Windows.Forms.MenuItem mnuRemoveShape;

        private bool selectSquareStatus = false;
        private bool selectTriangleStatus = false;
        private bool selectCircleStatus = false;

        private int clicknumber = 0;
        private Point one;
        private Point two;
        private Point three;

        // Keep track of when fake drag or resize mode is enabled.
        private bool isDragging = false;
        private bool isResizing = false;
        private int clickOffsetX, clickOffsetY;


        public Shapes()
        {
            InitializeComponent();

            this.mnuLabel = new System.Windows.Forms.ContextMenu();
            this.mnuRemoveShape = new System.Windows.Forms.MenuItem();
            // mnuLabel
            // 
            this.mnuLabel.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                     this.mnuRemoveShape});


            this.mnuRemoveShape.Index = 0;
            this.mnuRemoveShape.Text = "Remove Shape";
            this.mnuRemoveShape.Click += new System.EventHandler(this.mnuRemoveShape_Click);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DrawingShapes_MouseDown);
        }

        private void circleItem_Click(object sender, EventArgs e)
        {
            selectCircleStatus = true;
            MessageBox.Show("Click OK and then click once each at two locations to create a Circle");
        }

        private void squareItem_Click(object sender, EventArgs e)
        {
            selectSquareStatus = true;
            MessageBox.Show("Click OK and then click once each at two locations to create a square");
        }

        private void triangleItem_Click(object sender, EventArgs e)
        {
            selectTriangleStatus = true;
            MessageBox.Show("Click OK and then click once each at two locations to create a Triangle");           
        }


        private void DrawingShapes_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
               
               this.ContextMenu.Show(this, new Point(e.X, e.Y));
            }

        }

        private void Shapes_MouseClick(object sender, MouseEventArgs e)
        {
            

            if (e.Button == MouseButtons.Left)
            {
                // 'if' statements can distinguish different selected menu operations to implement.
                // There may be other (better, more efficient) approaches to event handling,
                // but this approach works.

                

                if (selectSquareStatus == true)
                {
                    
                    if (clicknumber == 0)
                    {
                        one = new Point(e.X, e.Y);
                        clicknumber = 1;
                    }
                    else
                    {
                        Shape newShape = new Shape();

                        two = new Point(e.X, e.Y);
                        clicknumber = 0;
                        selectSquareStatus = false;
                        newShape.Size = new Size(40, 40);
                        newShape.BackColor = Color.Transparent;

                        newShape.Type = Shape.ShapeType.Rectangle;
                        newShape.Location = this.PointToClient(Control.MousePosition);

                        newShape.ContextMenu = mnuLabel;
                        newShape.MouseDown += new MouseEventHandler(Shapes_MouseDown);
                        newShape.MouseMove += new MouseEventHandler(Shapes_MouseMove);
                        newShape.MouseUp += new MouseEventHandler(Shapes_MouseUp);
                        this.Controls.Add(newShape);
                    }
                }
                else if (selectTriangleStatus)
                {
                    
                    if (clicknumber == 0)
                    {
                        one = new Point(e.X, e.Y);
                        clicknumber = 1;
                    }
                    else if (clicknumber == 1)
                    {
                        two = new Point(e.X, e.Y);
                        clicknumber = 2;
                    }
                    else
                    {
                        Shape newShape = new Shape();
                        var dx = one.X - two.X;
                        var dy = one.Y - two.Y;
                        var dist = Math.Sqrt(dx * dx + dy * dy);


                        var dx1 = two.X - three.X;
                        var dy1 = two.Y - three.Y;
                        var dist1 = Math.Sqrt(dx1 * dx1 + dy1 * dy1);

                        var dx2 = three.X - one.X;
                        var dy2 = three.Y - one.Y;
                        var dist2 = Math.Sqrt(dx2 * dx2 + dy2 * dy2);

                        
                        three = new Point(e.X, e.Y);
                        clicknumber = 0;
                        selectTriangleStatus = false;
                        newShape.Size = new Size(60, 60);
                        newShape.Type = Shape.ShapeType.Triangle;
                        newShape.Location = this.PointToClient(new Point(one.X,one.X));

                        newShape.ContextMenu = mnuLabel;
                        newShape.MouseDown += new MouseEventHandler(Shapes_MouseDown);
                        newShape.MouseMove += new MouseEventHandler(Shapes_MouseMove);
                        newShape.MouseUp += new MouseEventHandler(Shapes_MouseUp);

                        this.Controls.Add(newShape);
                    }
                }
                else if (selectCircleStatus)
                {
                    
                    if (clicknumber == 0)
                    {
                        one = new Point(e.X, e.Y);
                        clicknumber = 1;
                    }
                    else
                    {
                        Shape newShape = new Shape();
                        two = new Point(e.X, e.Y);
                        clicknumber = 0;
                        selectCircleStatus = false;
                        newShape.Type = Shape.ShapeType.Ellipse;
                        newShape.Location = this.PointToClient(new Point(one.X, one.X));

                        newShape.ContextMenu = mnuLabel;
                        newShape.MouseDown += new MouseEventHandler(Shapes_MouseDown);
                        newShape.MouseMove += new MouseEventHandler(Shapes_MouseMove);
                        newShape.MouseUp += new MouseEventHandler(Shapes_MouseUp);
                        this.Controls.Add(newShape);
                    }
                }
                
            }   
        }


        private void Shapes_MouseDown(object sender, MouseEventArgs e)
        {
            Shape newShape = new Shape();
            // Retrieve a reference to the active label.
            Control currentCtrl;
            currentCtrl = (Control)sender;

            if (e.Button == MouseButtons.Left)
            {
                clickOffsetX = e.X;
                clickOffsetY = e.Y;

                if ((e.X + 5) > currentCtrl.Width || (e.Y + 5) > currentCtrl.Height)
                {
                    // The mouse pointer is in the bottom right corner,
                    // so resizing mode is appropriate.
                    isResizing = true;
                }
                else
                {
                    // The mouse is somewhere else, so dragging mode is
                    // appropriate.
                    isDragging = true;
                }
            }

            this.Controls.Add(newShape);
        }

        private void Shapes_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
            isResizing = false;
        }

        private void Shapes_MouseMove(object sender, MouseEventArgs e)
        {
            // Retrieve a reference to the active shape.
            Control currentCtrl;
            currentCtrl = (Control)sender;

            if (isDragging)
            {
                // Move the control.
                currentCtrl.Left = e.X + currentCtrl.Left - clickOffsetX;
                currentCtrl.Top = e.Y + currentCtrl.Top - clickOffsetY;
            }
            else if (isResizing)
            {
                // Resize the control, according to the resize mode.
                if (currentCtrl.Cursor == Cursors.SizeNWSE)
                {
                    currentCtrl.Width = e.X;
                    currentCtrl.Height = e.Y;
                }
                else if (currentCtrl.Cursor == Cursors.SizeNS)
                {
                    currentCtrl.Height = e.Y;
                }
                else if (currentCtrl.Cursor == Cursors.SizeWE)
                {
                    currentCtrl.Width = e.X;
                }
            }
            else
            {
                // Change the cursor if the mouse pointer is on one of the edges
                // of the control.
                if (((e.X + 5) > currentCtrl.Width) &&
                    ((e.Y + 5) > currentCtrl.Height))
                {
                    currentCtrl.Cursor = Cursors.SizeNWSE;
                }
                else if ((e.X + 5) > currentCtrl.Width)
                {
                    currentCtrl.Cursor = Cursors.SizeWE;
                }
                else if ((e.Y + 5) > currentCtrl.Height)
                {
                    currentCtrl.Cursor = Cursors.SizeNS;
                }
                else
                {
                    currentCtrl.Cursor = Cursors.Arrow;
                }
            }
        }

        private void Shapes_Load(object sender, EventArgs e)
        {

        }

        private void mnuRemoveShape_Click(object sender, EventArgs e)
        {
            Shape ctrlShape = (Shape)mnuLabel.SourceControl;
            this.Controls.Remove(ctrlShape);
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }


    public class Shape : System.Windows.Forms.UserControl
    {
        // The types of shapes supported by this control.
        public enum ShapeType
        {
            Rectangle,
            Ellipse,
            Triangle
        }

        private ShapeType shape = ShapeType.Rectangle;
        private GraphicsPath path = null;

        public ShapeType Type
        {
            get
            {
                return shape;
            }
            set
            {
                shape = value;
                RefreshPath();
                this.Invalidate();
            }
        }

        // Create the corresponding GraphicsPath for the shape, and apply
        // it to the control by setting the Region property.
        private void RefreshPath()
        {
            path = new GraphicsPath();
            switch (shape)
            {
                case ShapeType.Rectangle:
                    Point p1 = new Point(this.Width / 2, 0);
                    Point p2 = new Point(0, this.Height);
                    path.AddRectangle(new Rectangle());

                    path.AddRectangle(this.ClientRectangle);
                    break;
                case ShapeType.Ellipse:
                    path.AddEllipse(this.ClientRectangle);
                    break;
                case ShapeType.Triangle:
                    Point pt1 = new Point(this.Width / 2, 0);
                    Point pt2 = new Point(0, this.Height);
                    Point pt3 = new Point(this.Width, this.Height);
                    path.AddPolygon(new Point[] { pt1, pt2, pt3 });
                    break;
            }
            this.Region = new Region(path);
        }

        protected override void OnResize(System.EventArgs e)
        {
            base.OnResize(e);
            RefreshPath();
            this.Invalidate();
        }

        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            base.OnPaint(e);
            if (path != null)
            {
                //e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                //e.Graphics.FillPath(new SolidBrush(this.BackColor), path);
                e.Graphics.DrawPath(new Pen(this.ForeColor, 2), path);
            }
        }

    }
}
